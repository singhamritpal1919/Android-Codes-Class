package com.example.listviewexc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    EditText name,age,job;
    List<User> mylist;
    UserAdapter adapter;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        name = findViewById(R.id.name);
        age = findViewById(R.id.age);
        job = findViewById(R.id.job);
        submit = findViewById(R.id.btn2);
        ListView listView = findViewById(R.id.listv2);
        mylist = new ArrayList<>();

        adapter = new UserAdapter(this,mylist);

        listView.setAdapter(adapter);

        User u1 = new User("pargol",18,"Teacher");
        mylist.add(u1);

        listView.setAdapter(adapter);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = name.getText().toString();
                String userage = age.getText().toString();
                String userjob = job.getText().toString();
                if(username.isEmpty()|| userjob.isEmpty()||userage.isEmpty()){
                    Toast.makeText(MainActivity2.this, "Please fill all", Toast.LENGTH_SHORT).show();
                }else {
                    int usage = Integer.parseInt(userage);
                    User user = new User(username, usage, userjob);
                    mylist.add(user);
                    adapter.notifyDataSetChanged();
                    name.setText("");
                    age.setText("");
                    job.setText("");
                }
            }
        });
    }
}