package com.example.autoexcer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView autoCompleteTextView;
//    String[] teachers={"pargol","pary","rich","ronald","richard","parisa","Daniel"};
    EditText editText;
    Button button;
    ArrayList<String> myarraylist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.edt1);
        button = findViewById(R.id.btn1);
        myarraylist = new ArrayList<>();
        ArrayAdapter<String> myadapter = new ArrayAdapter<>(this, android.R.layout.select_dialog_item,myarraylist);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String teacher = editText.getText().toString();
                if(teacher.length()==0){
                    Toast.makeText(MainActivity.this, "Please put something", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    myarraylist.add(teacher);
                    myadapter.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "Added", Toast.LENGTH_SHORT).show();
                    editText.setText("");
                }
            }
        });


//        ArrayAdapter<String> myadapter = new ArrayAdapter<>(this, android.R.layout.select_dialog_item,teachers);
        autoCompleteTextView = findViewById(R.id.autocomplete);
        autoCompleteTextView.setThreshold(2);
        autoCompleteTextView.setAdapter(myadapter);

//        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                String result = (String) adapterView.getItemAtPosition(i);
//                Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
//            }
//        });
    }
}