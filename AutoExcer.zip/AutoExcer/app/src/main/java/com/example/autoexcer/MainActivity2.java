package com.example.autoexcer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    Spinner spinner;
    Button button;
    ArrayList<String> mylist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        spinner =findViewById(R.id.spin);
        button = findViewById(R.id.btn2);
        mylist = new ArrayList<>();
        mylist.add("Pargol");
        mylist.add("Daniel");
        mylist.add("Richard");
        mylist.add("Mahi");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,mylist);
        spinner.setAdapter(adapter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selectedItem = spinner.getSelectedItem().toString();
                Toast.makeText(MainActivity2.this, selectedItem, Toast.LENGTH_SHORT).show();
            }
        });
    }
}